﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SQLite;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class CarroController : Controller
    {

		[HttpPost]
		public IActionResult Buscar()
        {
			SQLiteConnection? sqlite_conn = null;
            SQLiteDataReader? dr = null;
			try
            {
                sqlite_conn = Conexao.Nova();
                sqlite_conn.Open();

                string sql = $"select * from carro";

                SQLiteCommand comandoSQL = new SQLiteCommand(sql, sqlite_conn);
                dr = comandoSQL.ExecuteReader();
                List<Carro> list = new List<Carro>();
                while (dr.Read())
                {
                    Carro carro = new Carro();
                    carro.Codigo = dr.GetInt32(0);
                    carro.Foto   = dr.GetString(1);
                    carro.Tipo   = dr.GetString(2);
                    carro.Valor  = dr.GetDouble(3);
                    list.Add(carro);
                }
				dr.Close();
				sqlite_conn.Close();
				
				return Json(list);
            }
            catch (Exception ex)
            {
				if (dr != null)
				{
					dr.Close();
				}
				if (sqlite_conn != null)
				{
					sqlite_conn.Close();
				}
				return Json(new List<Carro>());
            }
        }

		[HttpPost]
		public String Inserir(string foto, string tipo, double valor)
        {
			SQLiteConnection? sqlite_conn = null;
			try
            {
                sqlite_conn = Conexao.Nova();
                sqlite_conn.Open();
                string sql = $"insert into carro(foto,tipo,valor) values('{foto}','{tipo}',{valor})";
                SQLiteCommand comandoSQL = new SQLiteCommand(sql, sqlite_conn);
                string resposta;
                if (comandoSQL.ExecuteNonQuery() > 0)
                {
                    resposta = "Dados inseridos com sucesso!!!";
                }
                else
                {
                    resposta = "Não foi possível inserir!!!";
                }
                sqlite_conn.Close();
                return resposta;
            }
            catch (Exception ex)
            {
				if (sqlite_conn != null)
				{
					sqlite_conn.Close();
				}
				return "Não foi possível inserir!!!";
            }
        }

        [HttpPost]
        public String Alterar(int codigo, string foto, string tipo, double valor)
        {
			SQLiteConnection? sqlite_conn = null;
			try
            {
                sqlite_conn = Conexao.Nova();
                sqlite_conn.Open();
                string sql = $"update carro set foto='{foto}', tipo='{tipo}', valor='{valor}' where codigo={codigo}";
                SQLiteCommand comandoSQL = new SQLiteCommand(sql, sqlite_conn);
                string resposta;
                if (comandoSQL.ExecuteNonQuery() > 0)
                {
                    resposta = "Dados alterados com sucesso!!!";
                }
                else
                {
                    resposta = "Não foi possível alterar!!!";
                }
                sqlite_conn.Close();
                return resposta;
            }
            catch (Exception ex)
            {
				if (sqlite_conn != null)
				{
					sqlite_conn.Close();
				}
				return "Não foi possível alterar!!!";
            }
        }


		[HttpPost]
		public String Excluir(int codigo)
        {
            SQLiteConnection ?sqlite_conn = null;
            try
            {
                sqlite_conn = Conexao.Nova();
                sqlite_conn.Open();
                string sql = $"delete from carro where codigo={codigo}";
                SQLiteCommand comandoSQL = new SQLiteCommand(sql, sqlite_conn);
                string resposta;
                if (comandoSQL.ExecuteNonQuery() > 0)
                {
                    resposta = "Dados excluídos com sucesso!!!";
                }
                else
                {
                    resposta = "Não foi possível excluir!!!";
                }
                sqlite_conn.Close();
                return resposta;
            }
            catch (Exception ex)
            {
				if (sqlite_conn != null)
				{
					sqlite_conn.Close();
				}
				return "Não foi possível excluir!!!";
            }
        }
    }
}
